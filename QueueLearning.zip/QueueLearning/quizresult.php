<?php
$studentid = $_SESSION['StudentID'];
if (isset($_GET['score'])) {
    echo $score = '<h1>Your Score is : ' . $_GET['score'] . '</h1>';
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {}

        h1,
        h5 {
            margin-bottom: 20px;
        }

        .question-container {
            margin-bottom: 20px;
            overflow-y: auto;
        }

        .card {
            border: 1px solid #ccc;
            padding: 1em;
            margin-bottom: 1em;
        }

        .radio {
            margin-bottom: 1em;
        }

        form {
            margin-bottom: 2em;
        }

        .submit-form {
            text-align: right;
        }

        .question {
            margin-bottom: 1em;
            font-weight: bold;
        }

        .answer-container {
            margin-left: 1em;
        }

        /* Membuat card responsif */
        @media (max-width: 768px) {
            .card {
                padding: 0.5em;
                margin-bottom: 0.5em;
            }

            .radio {
                margin-bottom: 0.5em;
            }

            form {
                margin-bottom: 1em;
            }

            .question {
                margin-bottom: 0.5em;
            }

            .answer-container {
                margin-left: 0.5em;
            }
        }
    </style>
</head>

<body>
    <?php
    $id = $_GET['id'];
    if ($id == '') {
        redirect("index.php");
    }

    $sql = "SELECT * FROM tblexercise WHERE LessonID = '{$id}'";
    $mydb->setQuery($sql);
    $cur = $mydb->loadResultList();

    ?>
    <h1>Soal</h1>
    <h5>Review</h5>
    <div class="question-container" style="height: 400px; overflow-y: auto;">
        <?php
        $questionNumber = 1;
        foreach ($cur as $res) {

            $sql = "SELECT * FROM tblscore s, tblexercise e WHERE s.ExerciseID = e.ExerciseID AND s.ExerciseID = '{$res->ExerciseID}' and StudentID = '{$studentid}'";
            $mydb->setQuery($sql);
            $ans = $mydb->loadSingleResult();
        ?>
            <div class="card">
                <form>
                    <div class="question"><?php echo $questionNumber . ". " . $res->Question; ?></div>
                    <div class="answer-container">
                        <input class="radios" type="radio" disabled="true" <?php echo ($ans && $ans->Answer == $res->ChoiceA) ? 'CHECKED' : ''; ?>> A. <?php echo $res->ChoiceA; ?><br>
                        <input class="radios" type="radio" disabled="true" <?php echo ($ans && $ans->Answer == $res->ChoiceB) ? 'CHECKED' : ''; ?>> B. <?php echo $res->ChoiceB; ?><br>
                        <input class="radios" type="radio" disabled="true" <?php echo ($ans && $ans->Answer == $res->ChoiceC) ? 'CHECKED' : ''; ?>> C. <?php echo $res->ChoiceC; ?><br>
                        <input class="radios" type="radio" disabled="true" <?php echo ($ans && $ans->Answer == $res->ChoiceD) ? 'CHECKED' : ''; ?>> D. <?php echo $res->ChoiceD; ?><br>
                    </div>
                </form>
            </div>
            <br>
        <?php
            $questionNumber++;
        }
        ?>
    </div>
</body>

</html>