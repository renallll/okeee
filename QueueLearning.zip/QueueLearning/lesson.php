<style>

body {
    font-size: 18px;
  }

  h1, h2, h3, h4, h5, h6 {
    font-size: 24px;
  }

  p, li {
    font-size: 16px;
  }
    .table-responsive {
        margin-top: 20px;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 20px;
        box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.1);
        background-color: #fff;
    }

    table, th, td {
        border: 1px solid #ddd;
    }

    th, td {
        padding: 15px;
        text-align: left;
    }

    th {
        background-color: #f2f2f2;
    }

    tbody tr:hover {
        background-color: #f5f5f5;
    }

    .btn-info {
        background-color: #5bc0de;
        color: #fff;
    }

    .btn-info:hover {
        background-color: #31b0d5;
    }
</style>



<h1><?php echo $title; ?></h1>
<div class="col-lg-6">
    <h3>File Materi Queue (Pdf) </h3>
    <div class="table-responsive">
        <table id="example" class="table table-bordered">
            <thead>
                <th width="2%">#</th>
                <th>Silabus</th>
                <th>Judul</th>
                <th width="2%">Aksi</th>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT * FROM tbllesson WHERE Category='Docs'";
                $mydb->setQuery($sql);
                $cur = $mydb->loadResultList();
                foreach ($cur as $result) {
                    # code...
                    echo '<tr>';
                    echo '<td></td>';
                    echo '<td>' . $result->LessonChapter . '</td>';
                    echo '<td>' . $result->LessonTitle . '</td>';
                    echo '<td><a href="index.php?q=viewpdf&id=' . $result->LessonID . '" class="btn btn-xs btn-info"><i class="fa fa-info"></i> View File</a></td>';
                    echo '</tr>';
                }
                ?>
            </tbody>
        </table>
    </div>
</div>
<div class="col-lg-6">
    <h3>VIDEO</h3>
    <div class="table-responsive">
        <table id="example2" class="table table-bordered">
            <thead>
                <th width="2%">#</th>
                <th>Deskripsi</th>
                <th width="2%">Aksi</th>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT * FROM tbllesson WHERE Category='Video'";
                $mydb->setQuery($sql);
                $cur = $mydb->loadResultList();
                foreach ($cur as $result) {
                    # code...
                    echo '<tr>';
                    echo '<td></td>';
                    echo '<td>' . $result->LessonTitle . '</td>';
                    echo '<td><a href="index.php?q=playvideo&id=' . $result->LessonID . '" class="btn btn-xs btn-info"><i class="fa fa-play"></i> Play Video</a></td>';
                    echo '</tr>';
                }
                ?>
            </tbody>
        </table>
    </div>
</div>
