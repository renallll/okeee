var counter = -1;
var counter_arr = 0;
var pushcount = 0;
var popcount = 0;
var emptycount = 0;

var docWrapper = document.querySelector('.wrapper');

var pushModal = document.getElementById("pushmodal");
var popModal = document.getElementById("popmodal");
var emptyModal = document.getElementById("emptymodal");

var closePush = document.getElementsByClassName("close-push")[0];
var closePop = document.getElementsByClassName("close-pop")[0];
var closeEmpty = document.getElementsByClassName("close-empty")[0];

var push_algo = `
ENQUEUE(Q, FRONT, REAR, ITEM) <br/><br/>

Algorithm to enqueue an item into the queue.
<br/><br/>
1) IF REAR = SIZE-1 then <br/>
   Print "Queue is full"; <br/>
   Exit; <br/>
2) OTHERWISE <br/>
   REAR = REAR + 1;        /* increment REAR */ <br/>
   Q[REAR] = ITEM; <br/>
3) End of IF <br/>
4) Exit
`;

var pop_algo = `
DEQUEUE(Q, FRONT, REAR, ITEM) <br/><br/>

Algorithm to dequeue an element from the queue. <br/><br/>

1) IF FRONT = REAR then <br/>
    Print "Queue is empty"; <br/>
    Exit; <br/>
2) OTHERWISE <br/>
    FRONT = FRONT + 1; <br/>
    ITEM = Q[FRONT]; <br/>
3) End of IF <br/>
4) Exit
`;

var isempty_algo = `
IS_EMPTY(Q, FRONT, REAR, STATUS) <br/>
<br/>
Algorithm to check if the queue is empty or not. <br/>
STATUS contains the result status. <br/>
<br/>
1) IF FRONT = REAR then <br/>
    STATUS = true; <br/>
2) OTHERWISE <br/>
    STATUS = false; <br/>
3) End of IF <br/>
4) Exit
`;

var Q = [];
var FRONT = -1;
var REAR = -1;
var SIZE = 5; // You can adjust the size of the queue as 

var arr = [];

function push() {
  document.getElementById("current_algo").innerHTML = push_algo;
  if (document.getElementById("push-item").value) {
    if (pushcount == 1) {
      callPushBox();
    }

    if (counter == 8) {
      alert("Overflow: Stack full");
    } else {
      counter++;
      pushcount++;
      setTimeout(function () {
        callPushBox();
      }, 2000);
      document.getElementById("pointer").innerHTML = counter;

      arr.push(document.getElementById("push-item").value);
      $("#stack").prepend(
        '<div id="r' +
        counter +
        1 +
        '" class="stack_box">  ' +
        document.getElementById("push-item").value +
        " </div>"
      );
      document.getElementById("pushed").innerHTML = document.getElementById(
        "push-item"
      ).value;
      document.getElementById("top_element").innerHTML = arr[counter];
      $("#array").append(
        '<div id="a' +
        counter +
        '" class="array_box">  ' +
        document.getElementById("push-item").value +
        " </div>"
      );
      document.getElementById("push-item").value = "";
      document.getElementById("popped").innerHTML = "";
    }
  } else {
    alert("Input cannot be blank ");
  }
}

function enqueue() {
  document.getElementById("current_algo").innerHTML = push_algo;
  if (document.getElementById("enqueue-item").value) {
    if (pushcount == 1) {
      callPushBox();
    }

    if (REAR === SIZE - 1) {
      alert("Overflow: Queue is full");
    } else {
      REAR++;
      pushcount++;
      setTimeout(function () {
        callPushBox();
      }, 2000);
      document.getElementById("pointer").innerHTML = REAR;

      Q[REAR] = document.getElementById("enqueue-item").value;
      $("#queue").append(
        '<div id="q' +
        REAR +
        '" class="queue_box">  ' +
        document.getElementById("enqueue-item").value +
        " </div>"
      );

      document.getElementById("enqueue-item").value = "";
      document.getElementById("dequeued").innerHTML = "";
    }
  } else {
    alert("Input cannot be blank");
  }
}

function dequeue() {
  document.getElementById("current_algo").innerHTML = pop_algo;
  if (FRONT === REAR) {
    alert("Underflow: Queue is empty");
  } else {
    FRONT++;
    popcount++;
    setTimeout(function () {
      callPopBox();
    }, 2000);
    $("#q" + FRONT).remove();

    if (FRONT <= REAR) {
      document.getElementById("top_element").innerHTML = Q[FRONT];
    } else {
      document.getElementById("top_element").innerHTML = "";
    }

    document.getElementById("pointer").innerHTML = FRONT;
  }
}

function peek() {
  if (FRONT <= REAR) {
    alert("Element at Peek is: " + Q[FRONT]);
  } else {
    alert("Queue is empty.");
  }
}

function isempty() {
  emptycount++;
  setTimeout(function () {
    callEmptyBox();
  }, 6000);
  document.getElementById("current_algo").innerHTML = isempty_algo;
  if (FRONT === REAR) {
    alert("Yes, the given queue is empty! You can enqueue elements into it.");
  } else {
    alert("No, the given queue is not empty. It contains items.");
  }
}


function pop() {
  document.getElementById("current_algo").innerHTML = pop_algo;
  if (counter >= 0) {
    if (arr[counter] == undefined) {} else {
      document.getElementById("popped").innerHTML = arr[counter];
      document.getElementById("pushed").innerHTML = "";
      arr.pop();
    }
    $("#r" + counter + 1).remove();
    $("#a" + counter).remove();

    counter--;
    popcount++;
    setTimeout(function () {
      callPopBox();
    }, 2000);
    if (counter >= 0) {
      document.getElementById("top_element").innerHTML = arr[counter];
    } else {
      document.getElementById("top_element").innerHTML = "";
    }

    document.getElementById("pointer").innerHTML = counter;
  } else {
    counter = -1;
    alert("Underflow: Element cannot be popped");
    document.getElementById("top_element").innerHTML = "";
    document.getElementById("pointer").innerHTML = counter;
  }
}

function ispeak() {
  if (arr[counter] != undefined) alert("Element at Peak is : " + arr[counter]);
  else alert("Stack is empty.");
}

function isempty_stack() {
  emptycount++;
  setTimeout(function () {
    callEmptyBox();
  }, 6000);
  document.getElementById("current_algo").innerHTML = isempty_algo;
  if (counter < 0) {
    alert("Yes, the given stack is empty! You can PUSH elements into it ");
  } else {
    alert("No, the given stack is not empty. It contains items . ");
  }
}

var modal = document.getElementById("popup");
var btn = document.getElementById("launch");
var span = document.getElementsByClassName("close")[0];

btn.onclick = function () {
  popup.style.display = "block";
};

span.onclick = function () {
  popup.style.display = "none";
};

window.onclick = function (event) {
  if (event.target == popup) {
    popup.style.display = "none";
  }
};

function start() {
  var start = document.getElementById("start");
  start.className = start.className.replace(/\bshow\b/g, "hide");
  var prev = document.getElementById("prev");
  var next = document.getElementById("next");
  prev.className = prev.className.replace(/\bhide\b/g, "show");
  next.className = next.className.replace(/\bhide\b/g, "show");
  var moveable = document.getElementById("moveable");
  moveable.className = moveable.className.replace(/\bshow\b/g, "hide");
}

function reset() {
  window.location.reload();
  return false;
}

function input() {
  var choice = confirm("Have you read the Instructions properly?");
  if (choice == true) {
    var moveable = document.getElementById("moveable");
    moveable.className = moveable.className.replace(/\bhide\b/g, "show");

    $("#start-val").empty();
    $("#mid").empty();
    $("#last").empty();

    document.getElementById("moveable").scrollIntoView(true);

    popup.style.display = "none";
  } else {
    reset();
  }
}

var codetab = document.getElementById("code");
codetab.onclick = codetab.className.replace(/\bhide\b/g, "show");

function makeDragable(dragHandle, dragTarget) {
  let dragObj = null;
  let xOffset = 0;
  let yOffset = 0;

  document
    .querySelector(dragHandle)
    .addEventListener("mousedown", startDrag, true);
  document
    .querySelector(dragHandle)
    .addEventListener("touchstart", startDrag, true);

  function startDrag(e) {
    e.preventDefault();
    e.stopPropagation();
    dragObj = document.querySelector(dragTarget);
    dragObj.style.position = "absolute";
    let rect = dragObj.getBoundingClientRect();

    if (e.type == "mousedown") {
      xOffset = e.clientX - rect.left;
      yOffset = e.clientY - rect.top;
      window.addEventListener("mousemove", dragObject, true);
    } else if (e.type == "touchstart") {
      xOffset = e.targetTouches[0].clientX - rect.left;
      yOffset = e.targetTouches[0].clientY - rect.top;
      window.addEventListener("touchmove", dragObject, true);
    }
  }

  function dragObject(e) {
    e.preventDefault();
    e.stopPropagation();

    if (dragObj == null) {
      return;
    } else if (e.type == "mousemove") {
      dragObj.style.left = e.clientX - xOffset + "px";
      dragObj.style.top = e.clientY - yOffset + "px";
    } else if (e.type == "touchmove") {
      dragObj.style.left = e.targetTouches[0].clientX - xOffset + "px";
      dragObj.style.top = e.targetTouches[0].clientY - yOffset + "px";
    }
  }

  document.onmouseup = function (e) {
    if (dragObj) {
      dragObj = null;
      window.removeEventListener("mousemove", dragObject, true);
      window.removeEventListener("touchmove", dragObject, true);
    }
  };
}

makeDragable("#handle", "#moveable");

function callPushBox() {
  if (pushcount == 3) {
    var optionA = document.getElementById('option-a');
    var optionB = document.getElementById('option-b');
    var optionC = document.getElementById('option-c');
    var optionD = document.getElementById('option-d');

    pushModal.style.display = "block";
    docWrapper.classList.add('blur');

    optionA.onclick = function () {
      optionA.classList.add('wrong');
    };
    optionB.onclick = function () {
      optionB.classList.add('wrong');
    }
    optionC.onclick = function () {
      optionC.classList.add('wrong');
    };
    optionD.onclick = function () {
      optionD.classList.add('correct');
      closePush.style.visibility = "visible";
      pushcount += 1;
    };

    closePush.onclick = function () {
      pushModal.style.display = "none";
      docWrapper.classList.remove('blur');
    };
  }
}

function callPopBox() {
  if (popcount == 3) {
    var optionA = document.getElementById('pop-a');
    var optionB = document.getElementById('pop-b');
    var optionC = document.getElementById('pop-c');
    var optionD = document.getElementById('pop-d');

    popModal.style.display = "block";
    docWrapper.classList.add('blur');

    optionA.onclick = function () {
      optionA.classList.add('wrong');
    };
    optionB.onclick = function () {
      optionB.classList.add('correct');
      closePop.style.visibility = "visible";
      popcount += 1;
    };
    optionC.onclick = function () {
      optionC.classList.add('wrong');
    };
    optionD.onclick = function () {
      optionD.classList.add('wrong');
    };

    closePop.onclick = function () {
      popModal.style.display = "none";
      docWrapper.classList.remove('blur');
    };
  }
}

function callEmptyBox() {
  if (emptycount == 1) {
    var optionA = document.getElementById('empty-a');
    var optionB = document.getElementById('empty-b');
    var optionC = document.getElementById('empty-c');
    var optionD = document.getElementById('empty-d');

    emptyModal.style.display = "block";
    docWrapper.classList.add('blur');

    optionA.onclick = function () {
      optionA.classList.add('wrong');
    };
    optionB.onclick = function () {
      optionB.classList.add('correct');
      closeEmpty.style.visibility = "visible";
      emptycount += 1;
    };
    optionC.onclick = function () {
      optionC.classList.add('wrong');
    };
    optionD.onclick = function () {
      optionD.classList.add('wrong');
    };

    closeEmpty.onclick = function () {
      emptyModal.style.display = "none";
      docWrapper.classList.remove('blur');
    };
  }
}