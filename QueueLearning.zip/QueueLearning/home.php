<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>QUEUE</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Bootstrap CSS -->
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" rel="stylesheet">

  <style>
  body {
    font-size: 20px;
  }

  h1, h2, h3, h4, h5, h6 {
    font-size: 24px;
  }

  p, li {
    font-size: 18px;
  }
</style>

</head>
<body>

<div class="container">
  <h1 class="mt-4">Aplikasi Pembelajaran Queue</h1>

  <div class="row">
    <div class="col-lg-12">
      <div class="card mb-4">
        <div class="card-body">
          <h4 class="card-title">Queue</h4>
          <p class="card-text">
          Queue merupakan struktur data linier yang menerapkan prinsip operasi dimana
elemen data yang masuk pertama akan keluar lebih dulu. Prinsip ini dikenal dengan
istilah FIFO (First In, First Out). Queue dalam kehidupan sehari-hari dapat ditemukan
di berbagai situasi. Misalnya, saat kita mengantri di sebuah toko, bank, atau tempat
layanan pelanggan. Selain itu, Queue juga digunakan dalam sistem pemrosesan data,
seperti antrian pesan di aplikasi komunikasi atau penjadwalan tugas pada sistem
operasi
          </div>
      </div>
    </div>

    <div class="col-lg-6">
      <div class="card mb-4">
        <div class="card-body">
          <h4 class="card-title">Array</h4>
          <p class="card-text">Array merupakan Kumpulan elemen yang bertipe sama dalam urutan tertentu
yang menggunakan nama yang sama. Letak atau posisi dari elemen array ditunjukkan
oleh index atau posisi. Dalam beberapa buku, array sering juga disebut dengan istilah
Larik atau Tabel. Array termasuk dalam struktur data statis, artinya adalah lokasi
memori untuk suatu array tidak dapat ditambah atau dikurangi selama program
5
dijalankan. Maka untuk mengubah ukuran dari lokasi memori suatu array harus
diperbaiki dalam listing programnya </div>
      </div>

      <div class="card mb-4">
        <div class="card-body">
          <h4 class="card-title">Struktur</h4>
          <p class="card-text">Structure (struktur) adalah kumpulan elemen data yang digabungkan menjadi
satu kesatuan. Dengan kata lain, structure merupakan bentuk struktur data yang dapat
menyimpan variabel-variabel dalam suatu nama. Masing-masing elemen data dengan
sebutan field. Masing-masing field dapat memiliki tipe data yang sama ataupun
berbeda </div>
      </div>

      <div class="card mb-4">
        <div class="card-body">
          <h4 class="card-title">Pointer</h4>
          <p class="card-text">Pointer (variabel penunjuk) adalah suatu variabel yang berisi alamat memori
dari suatu variabel lain. Alamat ini merupakan lokasi dari variabel dari dalam memori.
Dengan kata lain, pointer berisi alamat dari variabel yang mempunyai nilai tertentu. </div>
      </div>

      

      <div class="card mb-4">
        <div class="card-body">
          <h4 class="card-title">Core Values</h4>
          <ol>
            <li>Sorting</li>
            <li>Linked List</li>
            <li>Tree</li>
          </ol>
        </div>
      </div>
    </div>

    <div class="col-lg-6">
      <div class="card mb-4">
        <div class="card-body">
          <h4 class="card-title">Guiding Principles</h4>
          <ul>
            <li>E-Learning </li>
            <li>Antrian</li>
            <li>Simulasi</li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Bootstrap JS and dependencies -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
</body>
</html>
