<?php
$studentid = $_SESSION['StudentID'];
$score = 0;
$id = $_GET['id'];
if ($id == '') {
    redirect("index.php");
}

$sql = "SELECT SUM(Score) as 'SCORE' FROM tblscore  WHERE LessonID='{$id}' and StudentID='{$studentid}' AND Submitted=1";
$mydb->setQuery($sql);
$row = $mydb->executeQuery();
$ans = $mydb->loadSingleResult();
$score  = $ans->SCORE;

if ($score != null) {
    redirect("index.php?q=quizresult&id={$id}&score={$score}");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {}

        h1,
        h5 {
            margin-bottom: 20px;
        }

        .question-container {
            margin-bottom: 20px;
            overflow-y: auto;
        }

        .card {
            border: 1px solid #ccc;
            padding: 1em;
            /* Gunakan unit em untuk padding */
            margin-bottom: 1em;
            /* Gunakan unit em untuk margin-bottom */
        }

        .radio {
            margin-bottom: 1em;
            /* Gunakan unit em untuk margin-bottom */
        }

        form {
            margin-bottom: 2em;
            /* Gunakan unit em untuk margin-bottom */
        }

        .submit-form {
            text-align: right;
        }

        .question {
            margin-bottom: 1em;
            /* Gunakan unit em untuk margin-bottom */
            font-weight: bold;
            /* Teks pertanyaan menjadi tebal */
        }

        .answer-container {
            margin-left: 1em;
            /* Gunakan unit em untuk margin-left */
        }

        /* Membuat card responsif */
        @media (max-width: 768px) {
            .card {
                padding: 0.5em;
                margin-bottom: 0.5em;
            }

            .radio {
                margin-bottom: 0.5em;
            }

            form {
                margin-bottom: 1em;
            }

            .question {
                margin-bottom: 0.5em;
            }

            .answer-container {
                margin-left: 0.5em;
            }
        }
    </style>
</head>

<body>
    <h1>Soal</h1>
    <h5>Pilih Jawaban Yang Benar.</h5>

    <div class="question-container" style="height: 400px; overflow-y: auto;">
        <?php
        $sql = "SELECT * FROM tblexercise WHERE LessonID = '{$id}'";
        $mydb->setQuery($sql);
        $cur = $mydb->loadResultList();

        $questionNumber = 1;

        foreach ($cur as $res) {
        ?>
            <div class="card">
                <form>
                    <div class="question"><?php echo $questionNumber . ". " . $res->Question; ?></div>
                    <div class="answer-container">
                        <div class="col-md-3"><input class="radios" type="radio" id="ChoiceA" data-id="<?php echo $res->ExerciseID; ?>" name="choices" value="<?php echo $res->ChoiceA; ?>"> A. <?php echo $res->ChoiceA; ?></div>
                        <div class="col-md-3"><input class="radios" type="radio" id="ChoiceB" data-id="<?php echo $res->ExerciseID; ?>" name="choices" value="<?php echo $res->ChoiceB; ?>"> B. <?php echo $res->ChoiceB; ?></div>
                        <div class="col-md-3"><input class="radios" type="radio" id="ChoiceC" data-id="<?php echo $res->ExerciseID; ?>" name="choices" value="<?php echo $res->ChoiceC; ?>"> C. <?php echo $res->ChoiceC; ?></div>
                        <div class="col-md-3"><input class="radios" type="radio" id="ChoiceD" data-id="<?php echo $res->ExerciseID; ?>" name="choices" value="<?php echo $res->ChoiceD; ?>"> D. <?php echo $res->ChoiceD; ?></div> <br><br><br></br>
                    </div> <br><br> </br>
                </form>
            </div>

        <?php
            $questionNumber++;
        }
        ?>
    </div>

    <form action="processscore.php" method="POST" class="submit-form">
        <input type="hidden" name="LessonID" value="<?php echo $id ?>">
        <button class="btn btn-md btn-primary" type="submit" name="btnSubmit">Submit <i class="fa fa-arrow-right"></i></button>
    </form>
</body>

</html>