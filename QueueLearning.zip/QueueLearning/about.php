<style>
  body {
    font-size: 20px;
  }

  h1, h2, h3, h4, h5, h6 {
    font-size: 24px;
  }

  p, li {
    font-size: 16px;
  }
</style>
<h1><?php echo $title;?></h1>
<p>Queue merupakan struktur data linier yang menerapkan prinsip operasi dimana elemen data yang masuk pertama akan keluar lebih dulu. Prinsip ini dikenal dengan istilah FIFO (First In, First Out). Queue dalam kehidupan sehari-hari dapat ditemukan di berbagai situasi. Misalnya, saat kita mengantri di sebuah toko, bank, atau tempat layanan pelanggan. Selain itu, Queue juga digunakan dalam sistem pemrosesan data, seperti antrian pesan di aplikasi komunikasi atau penjadwalan tugas pada sistem operasi</p>

<p>aplikasi pembelajaran queue ini bertujuan untuk mengembangkan efektivitas dalam pembelajaran queue. Dengan adanya penelitian ini, diharapkan dapat memberikan kontribusi dalam meningkatkan pembelajaran queue, memfasilitasi pemahaman mahasiswa, dan membantu mereka menguasai konsep tersebut secara lebih baik. Aplikasi pembelajaran queue dapat membantu sistem memahami penggunaan queue dalam implementas</p>

<div class="login100-pic js-tilt" data-tilte>
          <img src="<?php echo web_root; ?>/assets/images/simulationqueue.png" style="width:1150px;height:500px;" alt="IMG" >
        </div>
         