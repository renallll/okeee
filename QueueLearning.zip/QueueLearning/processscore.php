<?php
require_once("include/initialize.php");

$score = 0;
$studentid = $_SESSION['StudentID'];
$lessonid = $_POST['LessonID'];

$sql = "UPDATE tblscore SET Submitted = 1 WHERE LessonID='{$lessonid}' AND StudentID='{$studentid}'";
$mydb->setQuery($sql);
$mydb->executeQuery();

$sql = "SELECT COUNT(*) AS total_pertanyaan FROM tblexercise WHERE LessonID='{$lessonid}'";
$mydb->setQuery($sql);
$total_pertanyaan = $mydb->loadSingleResult()->total_pertanyaan;

$sql = "SELECT COUNT(*) AS jumlah_jawaban_benar FROM tblscore WHERE LessonID='{$lessonid}' AND StudentID='{$studentid}' AND Score = 1";
$mydb->setQuery($sql);
$jumlah_jawaban_benar = $mydb->loadSingleResult()->jumlah_jawaban_benar;

// Menghitung nilai berdasarkan persamaan
$nilai_maksimum = 100;
$nilai = ($jumlah_jawaban_benar / $total_pertanyaan) * $nilai_maksimum;

message("Exercises already submitted.", "success");
redirect("index.php?q=quizresult&id={$lessonid}&score={$nilai}");
