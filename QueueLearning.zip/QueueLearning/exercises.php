<style>
	body {
		font-size: 20px;
	}

	h1,
	h2,
	h3,
	h4,
	h5,
	h6 {
		font-size: 24px;
	}

	p,
	li {
		font-size: 16px;
	}
</style>

<h1><?php echo $title; ?></h1>

<div class="col-lg-12">
	<div class="table-responsive">
		<table id="example" class="table table-bordered">
			<thead>
				<th width="2%">#</th>
				<th>Silabus</th>
				<th>Judul</th>
				<th width="10%">Aksi</th>
			</thead>
			<tbody>
				<?php
				$sql = "SELECT * FROM tbllesson";
				$mydb->setQuery($sql);
				$cur = $mydb->loadResultList();
				foreach ($cur as $result) {
					# code...
					echo '<tr>';
					echo '<td></td>';
					echo '<td>' . $result->LessonChapter . '</td>';
					echo '<td>' . $result->LessonTitle . '</td>';
					echo '<td><a href="index.php?q=question&id=' . $result->LessonID . '" class="btn btn-xs btn-info">View Exercises</a></td>';
					echo '</tr>';
				}
				?>
			</tbody>
		</table>
	</div>
</div>